package com.example.task_movil_api.producto;

import java.util.List;

import com.example.task_movil_api.producto.dto.ProductoCreateDto;
import com.example.task_movil_api.producto.dto.ProductoUpdateDto;

public interface ProductoUseCase {
    Producto create(ProductoCreateDto dto);
    List<Producto> findAll();
    Producto findById(Long id);
    Producto update(Long id, ProductoUpdateDto dto);
    void delete(Long id);
}
