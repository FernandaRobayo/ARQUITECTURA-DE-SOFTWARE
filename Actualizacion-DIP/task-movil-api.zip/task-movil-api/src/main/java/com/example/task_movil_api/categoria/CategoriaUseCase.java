package com.example.task_movil_api.categoria;

import java.util.List;

import com.example.task_movil_api.categoria.dto.CategoriaCreateDto;
import com.example.task_movil_api.categoria.dto.CategoriaUpdateDto;

public interface CategoriaUseCase {
    Categoria create(CategoriaCreateDto dto);
    List<Categoria> findAll();
    Categoria findById(Long id);
    Categoria update(Long id, CategoriaUpdateDto dto);
    void delete(Long id);
}
